"use strict";
(() => {
  // src/background/background.ts
  var FOLLOWING_PATH = /\/following\/?$/u;
  var isXUrl = (url) => url !== void 0 && (url.includes("x.com") || url.includes("twitter.com"));
  var isFollowingUrl = (url) => {
    try {
      return FOLLOWING_PATH.test(new URL(url).pathname);
    } catch {
      return false;
    }
  };
  var ensureContentScript = async (tabId) => {
    try {
      const [probe] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => ({
          marker: document.documentElement?.getAttribute("data-xfm-extension") ?? null,
          toolbar: document.querySelector("[data-xfm-following-toolbar-host]") !== null,
          checkboxes: document.querySelectorAll("[data-xfm-follow-select-input]").length
        })
      });
      const state = probe?.result;
      if (state?.toolbar === true) return;
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content/following-manager.js"]
      });
    } catch {
    }
  };
  var injectOpenXFollowingTabs = async () => {
    const tabs = await chrome.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    for (const tab of tabs) {
      if (tab.id === void 0 || tab.url === void 0) continue;
      if (!isFollowingUrl(tab.url)) continue;
      await ensureContentScript(tab.id);
    }
  };
  chrome.runtime.onInstalled.addListener(() => {
    void injectOpenXFollowingTabs();
  });
  chrome.runtime.onStartup.addListener(() => {
    void injectOpenXFollowingTabs();
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== "complete" || tab.url === void 0) return;
    if (!isXUrl(tab.url) || !isFollowingUrl(tab.url)) return;
    void ensureContentScript(tabId);
  });
})();
