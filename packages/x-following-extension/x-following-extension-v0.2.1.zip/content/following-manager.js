"use strict";
(() => {
  // src/dom/x-session.ts
  var RESERVED_HANDLES = /* @__PURE__ */ new Set([
    "home",
    "explore",
    "notifications",
    "messages",
    "compose",
    "search",
    "settings",
    "i"
  ]);
  var PROFILE_LINK_SELECTORS = [
    'a[data-testid="AppTabBar_Profile_Link"]',
    'a[data-testid="SideNav_AccountSwitcher_Button"]',
    'a[data-testid="DashButton_ProfileIcon_Link"]',
    'a[data-testid="AccountSwitcher_Profile_Link"]'
  ];
  var profilePathToUserKey = (pathname) => {
    const segments = pathname.replace(/^\//u, "").split("/").filter(Boolean);
    if (segments.length === 0) return null;
    if (segments[0] === "i" && segments[1] === "user" && segments[2]) {
      return `id:${segments[2].toLowerCase()}`;
    }
    const handle = segments[0]?.toLowerCase();
    if (handle === void 0 || RESERVED_HANDLES.has(handle)) return null;
    return handle;
  };
  var followingPageUserKey = (pathname) => {
    if (!/\/following\/?$/u.test(pathname)) return null;
    return profilePathToUserKey(pathname.replace(/\/following\/?$/u, "") || "/");
  };
  var isFollowingListPage = (pathname) => followingPageUserKey(pathname) !== null;
  var collectProfileUserKeys = (root = document) => {
    const keys = /* @__PURE__ */ new Set();
    for (const selector of PROFILE_LINK_SELECTORS) {
      for (const link of root.querySelectorAll(selector)) {
        const key = profilePathToUserKey(link.pathname);
        if (key !== null) keys.add(key);
      }
    }
    return [...keys];
  };
  var readLoggedInUserKey = (root = document) => {
    const keys = collectProfileUserKeys(root);
    if (keys.length > 0) return keys[0] ?? null;
    const settingsLink = root.querySelector('a[href="/settings/profile"]');
    if (settingsLink !== null) {
      const accountLink = root.querySelector(
        'a[data-testid="SideNav_AccountSwitcher_Button"], a[href^="/"][role="link"]'
      );
      const key = accountLink === null ? null : profilePathToUserKey(accountLink.pathname);
      if (key !== null) return key;
    }
    return null;
  };
  var inferOwnFollowingFromTabs = (pathname, root = document) => {
    const pageKey = followingPageUserKey(pathname);
    if (pageKey === null) return false;
    const column = root.querySelector('[data-testid="primaryColumn"]');
    if (column === null) return false;
    const selectedTab = column.querySelector(
      `a[href="/${pageKey}/following"][aria-selected="true"], a[href="/${pageKey}/following"][aria-current="page"]`
    );
    return selectedTab !== null;
  };
  var FOLLOWING_TAB_ACTIVE_SELECTORS = [
    'a[role="tab"][aria-selected="true"]',
    'a[aria-selected="true"]'
  ];
  var FOLLOWING_TAB_HREF = /\/following\/?$/u;
  var FOLLOWING_TAB_LABEL = /^(正在关注|Following)$/u;
  var isFollowingTabActive = (root = document) => {
    for (const selector of FOLLOWING_TAB_ACTIVE_SELECTORS) {
      for (const tab of root.querySelectorAll(selector)) {
        const href = tab.getAttribute("href") ?? "";
        const label = tab.textContent?.trim() ?? "";
        if (FOLLOWING_TAB_HREF.test(href) || FOLLOWING_TAB_LABEL.test(label)) {
          return true;
        }
      }
    }
    return false;
  };
  var isOwnFollowingListPage = (pathname, loggedInUserKey, root = document) => {
    const pageKey = followingPageUserKey(pathname);
    if (pageKey === null) return false;
    if (!isFollowingTabActive(root)) return false;
    const keys = new Set(collectProfileUserKeys(root));
    if (loggedInUserKey !== null) keys.add(loggedInUserKey);
    if (keys.size > 0) return keys.has(pageKey);
    return inferOwnFollowingFromTabs(pathname, root);
  };

  // src/dom/following-filter.ts
  var USER_CELL_SELECTOR = '[data-testid="UserCell"]';
  var FOLLOWS_YOU_INDICATOR = '[data-testid="userFollowIndicator"]';
  var UNFOLLOW_BUTTON_SELECTOR = '[data-testid$="-unfollow"]';
  var CONFIRM_UNFOLLOW_SELECTOR = '[data-testid="confirmationSheetConfirm"]';
  var FILTER_STYLE_ID = "xfm-following-filter-style";
  var FILTER_HTML_ATTR = "data-xfm-filter";
  var FOLLOWS_YOU_LABELS = /^(Follows you|关注了你)$/u;
  var HANDLE_FROM_HREF = /^\/@?([A-Za-z0-9_]+)\/?$/u;
  var RESERVED_HANDLES2 = /* @__PURE__ */ new Set([
    "home",
    "explore",
    "notifications",
    "messages",
    "compose",
    "search",
    "settings",
    "i"
  ]);
  var filterCss = (mode) => {
    if (mode !== "one-way") return "";
    return `html[${FILTER_HTML_ATTR}="one-way"] [data-testid="UserCell"]:has(${FOLLOWS_YOU_INDICATOR}){display:none!important}`;
  };
  var setFollowingFilterMode = (mode) => {
    let style = document.getElementById(FILTER_STYLE_ID);
    if (style === null) {
      style = document.createElement("style");
      style.id = FILTER_STYLE_ID;
      document.head.append(style);
    }
    style.textContent = filterCss(mode);
    if (mode === "one-way") {
      document.documentElement.setAttribute(FILTER_HTML_ATTR, "one-way");
    } else {
      document.documentElement.removeAttribute(FILTER_HTML_ATTR);
    }
  };
  var removeFollowingFilterStyles = () => {
    document.getElementById(FILTER_STYLE_ID)?.remove();
    document.documentElement.removeAttribute(FILTER_HTML_ATTR);
  };
  var userCellFollowsYou = (cell) => {
    if (cell.querySelector(FOLLOWS_YOU_INDICATOR) !== null) return true;
    return [...cell.querySelectorAll("span")].some(
      (el) => FOLLOWS_YOU_LABELS.test(el.textContent?.trim() ?? "")
    );
  };
  var shouldShowOneWayFollowCell = (cell) => !userCellFollowsYou(cell);
  var shouldShowCheckboxOnCell = (cell, mode) => mode === "all" ? true : shouldShowOneWayFollowCell(cell);
  var parseHandleFromHref = (href) => {
    const path = href.split("?")[0]?.split("#")[0] ?? "";
    const match = path.match(HANDLE_FROM_HREF);
    if (match === null) return null;
    const handle = match[1].toLowerCase();
    if (RESERVED_HANDLES2.has(handle)) return null;
    return handle;
  };
  var extractUserCellHandle = (cell) => {
    const frequency = /* @__PURE__ */ new Map();
    for (const link of cell.querySelectorAll('a[href^="/"]')) {
      const handle = parseHandleFromHref(link.getAttribute("href") ?? "");
      if (handle !== null) {
        frequency.set(handle, (frequency.get(handle) ?? 0) + 1);
      }
    }
    if (frequency.size === 0) return null;
    return [...frequency.entries()].sort((a, b) => b[1] - a[1])[0][0];
  };
  var findUnfollowButton = (cell) => cell.querySelector(UNFOLLOW_BUTTON_SELECTOR);
  var listUserCells = (root = document) => [...root.querySelectorAll(USER_CELL_SELECTOR)];
  var findUserCellByHandle = (handle, root = document) => {
    const normalized = handle.toLowerCase();
    for (const cell of listUserCells(root)) {
      if (extractUserCellHandle(cell) === normalized) return cell;
    }
    return null;
  };
  var sleep = (ms) => new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
  var clickUnfollowConfirmation = async (timeoutMs = 4e3) => {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const confirm = document.querySelector(CONFIRM_UNFOLLOW_SELECTOR);
      if (confirm !== null) {
        confirm.click();
        await sleep(350);
        return true;
      }
      await sleep(120);
    }
    return false;
  };
  var unfollowUserCell = async (cell) => {
    const button = findUnfollowButton(cell);
    if (button === null) return false;
    button.click();
    return clickUnfollowConfirmation();
  };

  // src/dom/user-cell-checkbox.ts
  var CHECKBOX_INPUT_ATTR = "data-xfm-follow-select-input";
  var CHECKBOX_HIT_ATTR = "data-xfm-follow-select-hit";
  var CHECKBOX_PAD_ATTR = "data-xfm-follow-padded";
  var CHECKBOX_ROW_ATTR = "data-xfm-follow-row";
  var CHECKBOX_VISUAL_ATTR = "data-xfm-follow-select-visual";
  var HIT_ZONE_WIDTH_PX = 52;
  var CHECKBOX_RESERVE_STYLE_ID = "xfm-checkbox-reserve-style";
  var CHECKBOX_THEME_STYLE_ID = "xfm-checkbox-theme-style";
  var injectCheckboxTheme = () => {
    if (document.getElementById(CHECKBOX_THEME_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = CHECKBOX_THEME_STYLE_ID;
    style.textContent = [
      ":root {",
      "  --xfm-cb-border: rgba(255,255,255,0.12);",
      "  --xfm-cb-bg-checked: rgba(99,102,241,0.2);",
      "  --xfm-cb-border-checked: rgba(129,140,248,0.6);",
      "  --xfm-cb-glow: rgba(99,102,241,0.2);",
      "  --xfm-cb-check: white;",
      "}",
      "@media (prefers-color-scheme: light) {",
      "  :root {",
      "    --xfm-cb-border: rgba(0,0,0,0.18);",
      "    --xfm-cb-bg-checked: rgba(0,0,0,0.88);",
      "    --xfm-cb-border-checked: rgba(0,0,0,0.88);",
      "    --xfm-cb-glow: rgba(0,0,0,0.08);",
      "    --xfm-cb-check: white;",
      "  }",
      "}"
    ].join("\n");
    document.head.append(style);
  };
  var reserveCheckboxSpace = () => {
    if (document.getElementById(CHECKBOX_RESERVE_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = CHECKBOX_RESERVE_STYLE_ID;
    style.textContent = `:has(> [data-testid="UserCell"]){padding-left:${HIT_ZONE_WIDTH_PX}px;position:relative}`;
    document.head.append(style);
  };
  var removeCheckboxSpaceReservation = () => {
    document.getElementById(CHECKBOX_RESERVE_STYLE_ID)?.remove();
  };
  var createVisualSpan = () => {
    const span = document.createElement("span");
    span.setAttribute(CHECKBOX_VISUAL_ATTR, "true");
    span.style.cssText = [
      "width:20px",
      "height:20px",
      "border-radius:5px",
      "border:1.5px solid var(--xfm-cb-border)",
      "background:transparent",
      "display:flex",
      "align-items:center",
      "justify-content:center",
      "font-size:12px",
      "font-weight:700",
      "color:transparent",
      "flex-shrink:0",
      "transition:all 0.15s cubic-bezier(0.34,1.56,0.64,1)",
      "pointer-events:none"
    ].join(";");
    return span;
  };
  var updateVisualSpan = (span, checked) => {
    if (checked) {
      span.style.background = "var(--xfm-cb-bg-checked)";
      span.style.borderColor = "var(--xfm-cb-border-checked)";
      span.style.boxShadow = "0 0 24px var(--xfm-cb-glow)";
      span.style.color = "var(--xfm-cb-check)";
      span.textContent = "\u2713";
    } else {
      span.style.background = "transparent";
      span.style.borderColor = "var(--xfm-cb-border)";
      span.style.boxShadow = "none";
      span.style.color = "transparent";
      span.textContent = "";
    }
  };
  var updateVisualSpanInstant = (span, checked) => {
    span.style.transition = "none";
    void span.offsetHeight;
    updateVisualSpan(span, checked);
    void span.offsetHeight;
    span.style.transition = "all 0.15s cubic-bezier(0.34,1.56,0.64,1)";
  };
  var HIT_ZONE_HEIGHT_PX = 40;
  var hitZoneStyle = [
    "position:absolute",
    "left:0",
    "top:0",
    `width:${HIT_ZONE_WIDTH_PX}px`,
    `height:${HIT_ZONE_HEIGHT_PX}px`,
    "margin:0",
    "display:flex",
    "align-items:center",
    "justify-content:center",
    "cursor:pointer",
    "z-index:2",
    "touch-action:manipulation",
    "-webkit-tap-highlight-color:transparent"
  ].join(";");
  var inputStyle = [
    "position:absolute",
    "opacity:0",
    "width:1px",
    "height:1px",
    "margin:0",
    "pointer-events:none"
  ].join(";");
  var resolveUserCellMount = (cell) => {
    if (cell.matches('[data-testid="UserCell"]') && cell.parentElement instanceof HTMLElement) {
      return { mountEl: cell.parentElement, userCell: cell };
    }
    return { mountEl: cell, userCell: cell };
  };
  var findHitZone = (mount) => {
    const { mountEl, userCell } = mount;
    const prev = userCell.previousElementSibling;
    if (prev instanceof HTMLElement && prev.matches(`[${CHECKBOX_HIT_ATTR}]`)) return prev;
    return mountEl.querySelector(`:scope > [${CHECKBOX_HIT_ATTR}]`);
  };
  var normalizeHandle = (handle) => handle === null ? null : handle.toLowerCase();
  var findCheckboxInput = (mount, handle) => {
    const hit = findHitZone(mount);
    if (hit === null) return null;
    const input = hit.querySelector(`[${CHECKBOX_INPUT_ATTR}]`);
    if (input === null) return null;
    const normalized = normalizeHandle(handle);
    if (normalized === null || input.dataset.xfmHandle === normalized) return input;
    return null;
  };
  var syncInputHandleFromCurrentCell = (hit, input) => {
    const domCell = hit.nextElementSibling ?? hit.parentElement?.querySelector('[data-testid="UserCell"]') ?? null;
    if (domCell === null) return;
    const currentHandle = extractUserCellHandle(domCell);
    if (currentHandle !== null) input.dataset.xfmHandle = currentHandle;
  };
  var toggleInputFromHitZone = (hit, input) => {
    syncInputHandleFromCurrentCell(hit, input);
    input.checked = !input.checked;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  };
  var stopHitZoneEvent = (event) => {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  };
  var bindHitZoneInteraction = (hit, input) => {
    if (hit.dataset.xfmHitBound === "true") return;
    hit.dataset.xfmHitBound = "true";
    hit.tabIndex = 0;
    hit.setAttribute("role", "checkbox");
    hit.addEventListener(
      "pointerdown",
      (event) => {
        stopHitZoneEvent(event);
        hit.dataset.xfmPointerToggled = "true";
        toggleInputFromHitZone(hit, input);
      },
      { capture: true }
    );
    hit.addEventListener(
      "click",
      (event) => {
        stopHitZoneEvent(event);
        if (hit.dataset.xfmPointerToggled === "true") {
          delete hit.dataset.xfmPointerToggled;
          return;
        }
        toggleInputFromHitZone(hit, input);
      },
      { capture: true }
    );
    hit.addEventListener("keydown", (event) => {
      if (event.key !== " " && event.key !== "Enter") return;
      stopHitZoneEvent(event);
      toggleInputFromHitZone(hit, input);
    });
  };
  var findOrReuseCheckboxInput = (mount, handle) => {
    const normalized = normalizeHandle(handle);
    const matched = findCheckboxInput(mount, normalized);
    if (matched !== null) return matched;
    const hit = findHitZone(mount);
    if (hit === null) return null;
    const input = hit.querySelector(`[${CHECKBOX_INPUT_ATTR}]`);
    if (input === null) return null;
    if (normalized !== null) input.dataset.xfmHandle = normalized;
    return input;
  };
  var ensureUserCellCheckbox = (cell) => {
    const mount = resolveUserCellMount(cell);
    const handle = normalizeHandle(extractUserCellHandle(mount.userCell));
    const existingInput = findOrReuseCheckboxInput(mount, handle);
    if (existingInput !== null) {
      const existingHit = existingInput.closest(`[${CHECKBOX_HIT_ATTR}]`);
      if (existingHit !== null) bindHitZoneInteraction(existingHit, existingInput);
      return existingInput;
    }
    findHitZone(mount)?.remove();
    if (mount.mountEl.getAttribute(CHECKBOX_PAD_ATTR) !== "true") {
      const computed = window.getComputedStyle(mount.mountEl);
      const currentPad = Number.parseFloat(computed.paddingLeft) || 0;
      if (currentPad < HIT_ZONE_WIDTH_PX - 1) {
        mount.mountEl.style.paddingLeft = `${HIT_ZONE_WIDTH_PX}px`;
      }
      if (computed.position === "static") mount.mountEl.style.position = "relative";
      mount.mountEl.setAttribute(CHECKBOX_PAD_ATTR, "true");
      mount.mountEl.setAttribute(CHECKBOX_ROW_ATTR, "true");
    }
    const cellStyle = window.getComputedStyle(mount.userCell);
    const cellPadTop = Number.parseFloat(cellStyle.paddingTop) || 0;
    const hit = document.createElement("label");
    hit.setAttribute(CHECKBOX_HIT_ATTR, "true");
    hit.setAttribute("aria-label", "\u9009\u62E9\u6B64\u7528\u6237");
    hit.style.cssText = hitZoneStyle;
    hit.style.top = `${cellPadTop}px`;
    const input = document.createElement("input");
    input.type = "checkbox";
    input.setAttribute(CHECKBOX_INPUT_ATTR, "true");
    if (handle !== null) input.dataset.xfmHandle = handle;
    input.style.cssText = inputStyle;
    hit.append(input);
    const visual = createVisualSpan();
    updateVisualSpan(visual, input.checked);
    hit.append(visual);
    hit.setAttribute("aria-checked", String(input.checked));
    bindHitZoneInteraction(hit, input);
    input.addEventListener("change", () => {
      const vis = hit.querySelector(`[${CHECKBOX_VISUAL_ATTR}]`);
      if (vis) updateVisualSpan(vis, input.checked);
      hit.setAttribute("aria-checked", String(input.checked));
    });
    mount.mountEl.insertBefore(hit, mount.userCell);
    return input;
  };
  var removeUserCellCheckboxes = (root = document) => {
    for (const hit of root.querySelectorAll(`[${CHECKBOX_HIT_ATTR}]`)) {
      hit.remove();
    }
    for (const row of root.querySelectorAll(`[${CHECKBOX_ROW_ATTR}]`)) {
      if (row.getAttribute(CHECKBOX_PAD_ATTR) === "true") {
        row.style.removeProperty("padding-left");
        row.style.removeProperty("position");
        row.removeAttribute(CHECKBOX_PAD_ATTR);
        row.removeAttribute(CHECKBOX_ROW_ATTR);
      }
    }
  };
  var cellNeedsCheckboxAttach = (cell) => {
    const mount = resolveUserCellMount(cell);
    const handle = extractUserCellHandle(mount.userCell);
    return findCheckboxInput(mount, handle) === null;
  };
  var isUserCellInViewport = (cell) => {
    const { userCell } = resolveUserCellMount(cell);
    if (!userCell.isConnected) return false;
    const rect = userCell.getBoundingClientRect();
    if (rect.height < 8 || rect.width < 8) return false;
    return rect.bottom > 0 && rect.top < window.innerHeight;
  };
  var listScope = (root) => root.querySelector('[data-testid="primaryColumn"]') ?? root;
  var listLoadedUserCells = (mode, root = document) => {
    const scope = listScope(root);
    return [...scope.querySelectorAll('[data-testid="UserCell"]')].filter(
      (cell) => shouldShowCheckboxOnCell(cell, mode)
    );
  };
  var listViewportUserCells = (mode, root = document) => listLoadedUserCells(mode, root).filter((cell) => isUserCellInViewport(cell));
  var applyCheckboxChangeToSelection = (input, selectedHandles2) => {
    const handle = input.dataset.xfmHandle?.toLowerCase() ?? null;
    if (handle === null || handle.length === 0) return;
    const hit = input.closest(`[${CHECKBOX_HIT_ATTR}]`);
    if (hit instanceof HTMLElement) {
      const cell = hit.nextElementSibling ?? hit.parentElement?.querySelector('[data-testid="UserCell"]');
      if (cell instanceof HTMLElement) {
        const domHandle = extractUserCellHandle(cell);
        if (domHandle !== null && domHandle !== handle) return;
      }
    }
    if (input.dataset.xfmSyncing === "true") return;
    if (input.checked) selectedHandles2.add(handle);
    else selectedHandles2.delete(handle);
  };
  var setCellsChecked = (cells, checked, selectedHandles2) => {
    for (const cell of cells) {
      const mount = resolveUserCellMount(cell);
      const handle = normalizeHandle(extractUserCellHandle(mount.userCell));
      const input = findOrReuseCheckboxInput(mount, handle) ?? ensureUserCellCheckbox(cell);
      if (input.checked !== checked) {
        input.dataset.xfmSyncing = "true";
        input.checked = checked;
        delete input.dataset.xfmSyncing;
      }
      const visual = input.parentElement?.querySelector(`[${CHECKBOX_VISUAL_ATTR}]`);
      if (visual) updateVisualSpan(visual, input.checked);
      if (selectedHandles2 === void 0 || handle === null) continue;
      if (checked) selectedHandles2.add(handle);
      else selectedHandles2.delete(handle);
    }
  };
  var setAllLoadedChecked = (checked, mode, selectedHandles2, root = document) => {
    setCellsChecked(listLoadedUserCells(mode, root), checked, selectedHandles2);
  };
  var applySelectionToViewportCells = (selectedHandles2, mode, root = document) => {
    for (const cell of listViewportUserCells(mode, root)) {
      if (!shouldShowCheckboxOnCell(cell, mode)) continue;
      const mount = resolveUserCellMount(cell);
      const handle = normalizeHandle(extractUserCellHandle(mount.userCell));
      if (handle === null) continue;
      const input = findOrReuseCheckboxInput(mount, handle);
      if (input === null) continue;
      const shouldCheck = selectedHandles2.has(handle);
      if (input.checked !== shouldCheck) {
        input.dataset.xfmSyncing = "true";
        input.checked = shouldCheck;
        delete input.dataset.xfmSyncing;
        const visual = input.parentElement?.querySelector(`[${CHECKBOX_VISUAL_ATTR}]`);
        if (visual) updateVisualSpanInstant(visual, input.checked);
      }
    }
  };
  var syncCheckboxOnCell = (cell, selectedHandles2, mode) => {
    if (!shouldShowCheckboxOnCell(cell, mode)) return;
    const mount = resolveUserCellMount(cell);
    const handle = normalizeHandle(extractUserCellHandle(mount.userCell));
    if (handle === null) return;
    const shouldCheck = selectedHandles2.has(handle);
    const input = findOrReuseCheckboxInput(mount, handle) ?? ensureUserCellCheckbox(cell);
    if (input.dataset.xfmHandle !== handle) input.dataset.xfmHandle = handle;
    if (input.checked !== shouldCheck) {
      input.dataset.xfmSyncing = "true";
      input.checked = shouldCheck;
      delete input.dataset.xfmSyncing;
      const visual = input.parentElement?.querySelector(`[${CHECKBOX_VISUAL_ATTR}]`);
      if (visual) updateVisualSpanInstant(visual, input.checked);
    }
  };

  // src/ui/following-toolbar.ts
  var TOOLBAR_HOST_ATTR = "data-xfm-following-toolbar-host";
  var listFollowingToolbarHosts = (root = document) => [...root.querySelectorAll(`[${TOOLBAR_HOST_ATTR}]`)];
  var removeAllFollowingToolbarHosts = (root = document) => {
    for (const host of listFollowingToolbarHosts(root)) {
      host.remove();
    }
  };
  var FOLLOWING_TAB_HREF2 = /\/following\/?$/u;
  var FOLLOWING_TAB_LABEL2 = /^(正在关注|Following)$/u;
  var TABLIST_SELECTORS = [
    '[data-testid="ScrollSnap-List"][role="tablist"]',
    '[role="tablist"]'
  ];
  var findPrimaryColumn = () => document.querySelector('[data-testid="primaryColumn"]');
  var isFollowingTabAnchor = (anchor) => FOLLOWING_TAB_HREF2.test(anchor.pathname) || FOLLOWING_TAB_LABEL2.test(anchor.textContent?.trim() ?? "");
  var findFollowingTablist = () => {
    const column = findPrimaryColumn();
    if (column === null) return null;
    for (const selector of TABLIST_SELECTORS) {
      const tablist = column.querySelector(selector);
      if (tablist !== null) return tablist;
    }
    const tabAnchors = [...column.querySelectorAll("a[role='tab'], a[href]")];
    const followingTab = tabAnchors.find(
      (anchor) => anchor.getAttribute("aria-selected") === "true" && isFollowingTabAnchor(anchor)
    ) ?? tabAnchors.find((anchor) => isFollowingTabAnchor(anchor));
    if (followingTab === void 0) return null;
    return followingTab.closest('[role="tablist"]') ?? followingTab.parentElement ?? followingTab;
  };
  var findTabStickyStrip = (tablist) => {
    const column = findPrimaryColumn();
    let node = tablist;
    let stickyStrip = tablist;
    for (let depth = 0; depth < 12 && node !== null; depth += 1) {
      const style = window.getComputedStyle(node);
      if (style.position === "sticky" || style.position === "-webkit-sticky") {
        stickyStrip = node;
      }
      if (column !== null && node.parentElement === column) break;
      node = node.parentElement;
    }
    return stickyStrip;
  };
  var findFollowingInsertAnchor = (tablist) => {
    const strip = findTabStickyStrip(tablist);
    const next = strip.nextElementSibling;
    if (!(next instanceof HTMLElement)) return strip;
    const hasList = next.matches('[data-testid="UserCell"]') || next.querySelector('[data-testid="UserCell"]') !== null || next.matches("section[role='region'], section");
    if (hasList) return strip;
    const height = next.getBoundingClientRect().height;
    if (height <= 8) return next;
    return strip;
  };
  var resolveToolbarStickyTopPx = (tablist = findFollowingTablist()) => {
    if (tablist === null) return 0;
    const strip = findTabStickyStrip(tablist);
    const style = window.getComputedStyle(strip);
    const isSticky = style.position === "sticky" || style.position === "-webkit-sticky";
    const stickyTop = isSticky ? Number.parseFloat(style.top) || 0 : 0;
    return stickyTop + strip.offsetHeight;
  };
  var applyToolbarStickyLayout = (host) => {
    host.style.position = "sticky";
    host.style.zIndex = "3";
    host.style.top = `${resolveToolbarStickyTopPx()}px`;
    host.style.background = "var(--sticky-bg)";
    host.style.boxSizing = "border-box";
  };
  var findFollowingListInsertPoint = () => {
    const column = findPrimaryColumn();
    const tablist = findFollowingTablist();
    if (tablist !== null) {
      return { after: findFollowingInsertAnchor(tablist) };
    }
    const listSection = column?.querySelector('section[role="region"]') ?? column?.querySelector("section");
    if (listSection?.previousElementSibling instanceof HTMLElement) {
      return { after: listSection.previousElementSibling };
    }
    const firstCell = column?.querySelector('[data-testid="UserCell"]') ?? document.querySelector('[data-testid="UserCell"]');
    if (firstCell !== null) {
      const section = firstCell.closest("section");
      if (section?.previousElementSibling instanceof HTMLElement) {
        return { after: section.previousElementSibling };
      }
      const previous = firstCell.parentElement?.previousElementSibling;
      if (previous instanceof HTMLElement) return { after: previous };
    }
    return null;
  };
  var findFollowingToolbarFallbackAnchor = () => findPrimaryColumn() ?? document.querySelector('main[role="main"]');
  var isToolbarMountedAtListTop = (host, insertPoint) => {
    if (insertPoint === null) return false;
    if (!host.isConnected) return false;
    return host.previousElementSibling === insertPoint.after;
  };
  var mountFollowingToolbar = (insertPoint, fallbackAnchor, handlers, initialState) => {
    removeAllFollowingToolbarHosts();
    const host = document.createElement("div");
    host.setAttribute(TOOLBAR_HOST_ATTR, "true");
    applyToolbarStickyLayout(host);
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
  <style>
    :host {
      all: initial;
      display: block;
      font-family: -apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", sans-serif;
      -webkit-font-smoothing: antialiased;
      color-scheme: light dark;
      /* dark */
      --bg-base: #0a0a14;
      --bg-surface: rgba(18,18,32,0.7);
      --glass-border: rgba(255,255,255,0.06);
      --text-pri: rgba(255,255,255,0.9);
      --text-sec: rgba(255,255,255,0.5);
      --text-dim: rgba(255,255,255,0.3);
      --accent: #818cf8;
      --accent-glow: rgba(99,102,241,0.2);
      --danger: #ef4444;
      --danger-glow: rgba(239,68,68,0.3);
      --success: #10b981;
      --btn-bg: rgba(255,255,255,0.05);
      --btn-border: rgba(255,255,255,0.06);
      --seg-bg: rgba(255,255,255,0.04);
      --seg-active: rgba(129,140,248,0.22);
      --sticky-bg: rgb(0, 0, 0);
      --bar-glow: rgba(99,102,241,0.08);
      --badge-bg: rgba(255,255,255,0.05);
      --btn-hover: rgba(255,255,255,0.08);
      --progress-track-bg: rgba(255,255,255,0.06);
      --complete-bg: rgba(10,25,15,0.6);
      --complete-border: rgba(16,185,129,0.5);
      --dialog-overlay-bg: rgba(0,0,0,0.6);
      --dialog-panel-bg: rgba(24,24,44,0.88);
      --dialog-panel-border: rgba(255,255,255,0.08);
      --dialog-panel-shadow: 0 40px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04) inset;
      --dialog-icon-bg: rgba(239,68,68,0.12);
      --btn-cancel-bg: rgba(255,255,255,0.05);
      --btn-cancel-border: rgba(255,255,255,0.06);
      --btn-danger-border: rgba(239,68,68,0.2);
      --btn-danger-bg: linear-gradient(135deg, rgba(239,68,68,0.65), rgba(220,38,38,0.55));
      --btn-danger-hover-shadow: 0 6px 24px rgba(239,68,68,0.45);
      --progress-fill-bg: linear-gradient(90deg, rgba(239,68,68,0.4), rgba(239,68,68,0.8), rgba(248,113,113,0.9));
      --progress-dot-bg: rgb(248,113,113);
      --progress-dot-shadow: 0 0 8px rgba(248,113,113,0.6);
    }
    @media (prefers-color-scheme: light) {
      :host {
        --bg-base: #f2f2f7;
        --bg-surface: rgba(255,255,255,0.82);
        --glass-border: rgba(0,0,0,0.08);
        --text-pri: rgba(0,0,0,0.88);
        --text-sec: rgba(0,0,0,0.55);
        --text-dim: rgba(0,0,0,0.35);
        --accent: #1a1a2e;
        --accent-glow: rgba(0,0,0,0.08);
        --danger: #dc2626;
        --danger-glow: rgba(220,38,38,0.22);
        --success: #059669;
        --btn-bg: rgba(0,0,0,0.05);
        --btn-border: rgba(0,0,0,0.08);
        --seg-bg: rgba(0,0,0,0.05);
        --seg-active: rgba(0,0,0,0.88);
        --sticky-bg: rgb(242, 242, 247);
        --bar-glow: rgba(0,0,0,0.03);
        --badge-bg: rgba(0,0,0,0.06);
        --btn-hover: rgba(0,0,0,0.08);
        --progress-track-bg: rgba(0,0,0,0.08);
        --complete-bg: rgba(16,185,129,0.1);
        --complete-border: rgba(5,150,105,0.45);
        --dialog-overlay-bg: rgba(0,0,0,0.35);
        --dialog-panel-bg: rgba(255,255,255,0.94);
        --dialog-panel-border: rgba(0,0,0,0.08);
        --dialog-panel-shadow: 0 40px 80px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05) inset;
        --dialog-icon-bg: rgba(220,38,38,0.1);
        --btn-cancel-bg: rgba(0,0,0,0.05);
        --btn-cancel-border: rgba(0,0,0,0.08);
        --btn-danger-border: rgba(220,38,38,0.32);
        --btn-danger-bg: linear-gradient(135deg, #f43f3f, #e01d1d);
        --btn-danger-hover-shadow: 0 8px 32px rgba(239,68,68,0.55);
        --progress-fill-bg: linear-gradient(90deg, rgba(239,68,68,0.55), rgba(239,68,68,0.88), rgba(248,113,113,0.95));
        --progress-dot-bg: rgb(239,68,68);
        --progress-dot-shadow: 0 0 8px rgba(239,68,68,0.45);
      }
    }
    .bar {
      box-sizing: border-box;
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 14px 16px;
      background: var(--bg-surface);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-bottom: 1px solid var(--glass-border);
      color: var(--text-pri);
      overflow: hidden;
    }
    .bar::before {
      content: "";
      position: absolute;
      top: -30px;
      right: -20px;
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: radial-gradient(circle, var(--bar-glow), transparent 70%);
      pointer-events: none;
    }
    .header-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .title {
      font-size: 14px;
      font-weight: 700;
      color: var(--text-pri);
      letter-spacing: -0.01em;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .badge {
      font-size: 10px;
      font-weight: 500;
      color: var(--text-dim);
      background: var(--badge-bg);
      padding: 2px 7px;
      border-radius: 100px;
    }
    .stats {
      display: flex;
      gap: 14px;
      font-size: 11px;
      flex-shrink: 0;
    }
    .stat {
      color: var(--text-sec);
      white-space: nowrap;
    }
    .stat b { font-weight: 600; }
    .stat b.accent { color: var(--accent); }
    .stat b.danger { color: var(--danger); }
    .stat b.base { color: var(--text-pri); }

    .action-row {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: nowrap;
      overflow: hidden;
    }
    .segmented {
      display: flex;
      gap: 2px;
      background: var(--seg-bg);
      border-radius: 10px;
      padding: 2px;
    }
    .segmented button {
      border: none;
      padding: 7px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 500;
      color: var(--text-sec);
      background: transparent;
      cursor: pointer;
      transition: all 0.2s ease;
      font-family: inherit;
      white-space: nowrap;
    }
    .segmented button.active {
      background: var(--seg-active);
      color: white;
      font-weight: 600;
    }
    .segmented button:disabled { opacity: 0.4; cursor: not-allowed; }

    .spacer { flex: 1; }

    .btn {
      border: 1px solid var(--btn-border);
      border-radius: 8px;
      background: var(--btn-bg);
      color: var(--text-sec);
      font-size: 12px;
      font-weight: 500;
      padding: 7px 14px;
      cursor: pointer;
      transition: all 0.15s ease;
      font-family: inherit;
      white-space: nowrap;
    }
    .btn:hover { background: var(--btn-hover); }
    .btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .btn-danger {
      border: 1px solid var(--btn-danger-border);
      background: var(--btn-danger-bg);
      color: white;
      font-weight: 600;
      box-shadow: 0 4px 16px var(--danger-glow);
    }
    .btn-danger:hover:not(:disabled) {
      background: var(--btn-danger-bg);
    }

    .tip-row {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      min-height: 16px;
    }
    .tip-warn {
      color: var(--danger);
      flex-shrink: 1;
    }
    .tip-status {
      color: var(--text-dim);
      flex-shrink: 0;
      text-align: right;
    }
    .progress-wrap {
      display: none;
      flex-direction: column;
      gap: 8px;
    }
    .progress-wrap.show { display: flex; }
    .progress-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 12px;
      color: var(--text-sec);
    }
    .progress-track {
      height: 4px;
      background: var(--progress-track-bg);
      border-radius: 2px;
      overflow: hidden;
      position: relative;
    }
    .progress-fill {
      height: 100%;
      background: var(--progress-fill-bg);
      border-radius: 2px;
      transition: width 0.3s ease-out;
      position: relative;
    }
    .progress-fill::after {
      content: "";
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--progress-dot-bg);
      box-shadow: var(--progress-dot-shadow);
    }
    .progress-log {
      font-size: 11px;
      font-family: "SF Mono", "JetBrains Mono", monospace;
      color: var(--text-dim);
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .log-ok { color: rgba(16,185,129,0.7); }
    .log-fail { color: rgba(239,68,68,0.7); }
    .log-current { color: var(--text-sec); }

    .complete-wrap {
      display: none;
      align-items: center;
      gap: 12px;
      padding: 10px 14px;
      background: var(--complete-bg);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-left: 3px solid var(--complete-border);
      border-radius: 0 8px 8px 0;
    }
    .complete-wrap.show { display: flex; }
    .complete-icon { font-size: 16px; flex-shrink: 0; }
    .complete-text { font-size: 12px; color: var(--text-sec); flex: 1; }
    .complete-text b { color: var(--success); font-weight: 600; }
    .complete-timer { font-size: 11px; color: var(--text-dim); white-space: nowrap; }

    .dialog-overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 10000;
      background: var(--dialog-overlay-bg);
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
      align-items: center;
      justify-content: center;
    }
    .dialog-overlay.show { display: flex; }

    .dialog-panel {
      background: var(--dialog-panel-bg);
      backdrop-filter: blur(40px);
      -webkit-backdrop-filter: blur(40px);
      border: 1px solid var(--dialog-panel-border);
      border-radius: 20px;
      padding: 24px;
      width: 360px;
      max-width: 90vw;
      box-shadow: var(--dialog-panel-shadow);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 14px;
      text-align: center;
      animation: dialogIn 0.2s cubic-bezier(0.16,1,0.3,1);
    }

    @keyframes dialogIn {
      from { opacity: 0; transform: scale(0.9); }
      to { opacity: 1; transform: scale(1); }
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .dialog-icon {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: var(--dialog-icon-bg);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
    }
    .dialog-title { font-size: 15px; font-weight: 700; color: var(--text-pri); }
    .dialog-desc { font-size: 13px; color: var(--text-sec); }
    .dialog-desc b { color: var(--danger); font-weight: 600; }
    .dialog-note { font-size: 12px; color: var(--text-dim); }
    .dialog-actions {
      display: flex;
      gap: 8px;
      width: 100%;
      margin-top: 4px;
    }
    .dialog-actions .btn {
      flex: 1;
      padding: 10px;
      border-radius: 10px;
      font-size: 13px;
      text-align: center;
    }
    .dialog-actions .btn-cancel {
      background: var(--btn-cancel-bg);
      border: 1px solid var(--btn-cancel-border);
      color: var(--text-sec);
      font-weight: 500;
    }
    .dialog-actions .btn-confirm {
      background: linear-gradient(135deg, #ef4444, #dc2626);
      border: none;
      color: white;
      font-weight: 600;
    }

  </style>

  <div class="dialog-overlay" data-ref="dialog-overlay">
    <div class="dialog-panel">
      <div class="dialog-icon">\u26A0\uFE0F</div>
      <div class="dialog-title">\u786E\u8BA4\u53D6\u6D88\u5173\u6CE8</div>
      <div class="dialog-desc" data-ref="dialog-desc"></div>
      <div class="dialog-note">\u6B64\u64CD\u4F5C\u4E0D\u53EF\u64A4\u9500</div>
      <div class="dialog-actions">
        <button class="btn btn-cancel" data-action="dialog-cancel">\u53D6\u6D88</button>
        <button class="btn btn-confirm" data-action="dialog-confirm">\u786E\u8BA4\u53D6\u6D88\u5173\u6CE8</button>
      </div>
    </div>
  </div>

  <div class="bar">
    <div class="header-row">
      <div class="title">
        X \u6E05\u9053\u592B
        <span class="badge">BETA</span>
      </div>
      <div class="stats">
        <span class="stat">\u5217\u8868 <b class="base" data-ref="loaded-count">0</b> \u4EBA</span>
        <span class="stat">\u5DF2\u9009 <b class="accent" data-ref="selected-count">0</b> \u4EBA</span>
        <span class="stat">\u672A\u56DE\u5173 <b class="danger" data-ref="oneway-count">0</b> \u4EBA</span>
      </div>
    </div>

    <div class="action-row">
      <div class="segmented">
        <button data-action="filter-one-way" class="active">\u4EC5\u672A\u56DE\u5173</button>
        <button data-action="filter-all">\u5168\u90E8</button>
      </div>
      <div class="spacer"></div>
      <button class="btn" data-action="select-all">\u5168\u9009\u5217\u8868</button>
      <button class="btn" data-action="clear-selection">\u6E05\u9664\u9009\u62E9</button>
      <button class="btn btn-danger" data-action="unfollow-selected">\u53D6\u6D88\u5173\u6CE8\u6240\u9009</button>
    </div>

    <div class="tip-row">
	      <span class="tip-status" data-ref="status-text"></span>
	      <div class="spacer"></div>
	      <span class="tip-warn">\u26A0\uFE0F \u5EFA\u8BAE\u5206\u6279\u53D6\u5173\uFF0C\u6BCF\u5C0F\u65F6\u4E0D\u8D85\u8FC7 50 \u4EBA\uFF0C\u4EE5\u51CF\u5C11\u8D26\u53F7\u9650\u5236\u98CE\u9669\uFF01</span>
	    </div>

    <div class="progress-wrap" data-ref="progress-wrap">
      <div class="progress-header">
        <span>\u6B63\u5728\u53D6\u6D88\u5173\u6CE8\u2026</span>
        <span data-ref="progress-count">0 / 0</span>
      </div>
      <div class="progress-track">
        <div class="progress-fill" data-ref="progress-fill" style="width:0%"></div>
      </div>
      <div class="progress-log" data-ref="progress-log"></div>
    </div>

    <div class="complete-wrap" data-ref="complete-wrap">
      <span class="complete-icon">\u2705</span>
      <span class="complete-text" data-ref="complete-text"></span>
      <span class="complete-timer" data-ref="complete-timer"></span>
    </div>
  </div>
`;
    const dialogOverlay = shadow.querySelector('[data-ref="dialog-overlay"]');
    const dialogDesc = shadow.querySelector('[data-ref="dialog-desc"]');
    const loadedCountEl = shadow.querySelector('[data-ref="loaded-count"]');
    const selectedCountEl = shadow.querySelector('[data-ref="selected-count"]');
    const onewayCountEl = shadow.querySelector('[data-ref="oneway-count"]');
    const statusTextEl = shadow.querySelector('[data-ref="status-text"]');
    const progressWrap = shadow.querySelector('[data-ref="progress-wrap"]');
    const progressFill = shadow.querySelector('[data-ref="progress-fill"]');
    const progressCount = shadow.querySelector('[data-ref="progress-count"]');
    const progressLog = shadow.querySelector('[data-ref="progress-log"]');
    const completeWrap = shadow.querySelector('[data-ref="complete-wrap"]');
    const completeText = shadow.querySelector('[data-ref="complete-text"]');
    const filterOneWay = shadow.querySelector('[data-action="filter-one-way"]');
    const filterAll = shadow.querySelector('[data-action="filter-all"]');
    const unfollowBtn = shadow.querySelector('[data-action="unfollow-selected"]');
    filterOneWay.addEventListener("click", () => {
      if (filterOneWay.classList.contains("active")) return;
      handlers.onFilterModeChange("one-way");
    });
    filterAll.addEventListener("click", () => {
      if (filterAll.classList.contains("active")) return;
      handlers.onFilterModeChange("all");
    });
    shadow.querySelector('[data-action="select-all"]')?.addEventListener("click", () => handlers.onSelectAll());
    shadow.querySelector('[data-action="clear-selection"]')?.addEventListener("click", () => handlers.onClearSelection());
    unfollowBtn.addEventListener("click", () => handlers.onUnfollowSelected());
    let dialogResolve = null;
    shadow.querySelector('[data-action="dialog-cancel"]')?.addEventListener("click", () => {
      dialogOverlay.classList.remove("show");
      dialogResolve?.(false);
      dialogResolve = null;
    });
    shadow.querySelector('[data-action="dialog-confirm"]')?.addEventListener("click", () => {
      dialogOverlay.classList.remove("show");
      dialogResolve?.(true);
      dialogResolve = null;
    });
    dialogOverlay.addEventListener("click", (e) => {
      if (e.target === dialogOverlay) {
        dialogOverlay.classList.remove("show");
        dialogResolve?.(false);
        dialogResolve = null;
      }
    });
    const confirmUnfollow = (_loadedCount, totalSelected) => new Promise((resolve) => {
      dialogDesc.innerHTML = `\u5C06\u53D6\u6D88\u5173\u6CE8 <b>${totalSelected}</b> \u4E2A\u8D26\u53F7`;
      dialogResolve = resolve;
      dialogOverlay.classList.add("show");
    });
    let lastSignature = "";
    const stateSignature = (s) => `${s.filterMode}|${s.loadedCount}|${s.selectedCount}|${s.busy}|${s.phase}|${s.oneWayCount}|${s.progress?.done ?? 0}|${s.progress?.total ?? 0}|${s.completeResult?.succeeded ?? 0}|${s.completeResult?.failed ?? 0}`;
    const paint = (state) => {
      const sig = stateSignature(state);
      if (sig === lastSignature) return;
      lastSignature = sig;
      loadedCountEl.textContent = String(state.loadedCount);
      selectedCountEl.textContent = String(state.selectedCount);
      onewayCountEl.textContent = String(state.oneWayCount);
      statusTextEl.textContent = state.statusText;
      if (state.filterMode === "one-way") {
        filterOneWay.classList.add("active");
        filterAll.classList.remove("active");
      } else {
        filterAll.classList.add("active");
        filterOneWay.classList.remove("active");
      }
      const allButtons = shadow.querySelectorAll("button:not(.dialog-actions button)");
      allButtons.forEach((btn) => {
        btn.disabled = state.busy;
      });
      filterOneWay.disabled = state.busy;
      filterAll.disabled = state.busy;
      if (state.phase === "progress" && state.progress) {
        progressWrap.classList.add("show");
        completeWrap.classList.remove("show");
        const pct = state.progress.total > 0 ? state.progress.done / state.progress.total * 100 : 0;
        progressFill.style.width = `${pct}%`;
        progressCount.textContent = `${state.progress.done} / ${state.progress.total}`;
        progressLog.innerHTML = state.progress.recentLog.map((entry) => {
          const cls = entry.succeeded ? "log-ok" : "log-fail";
          const mark = entry.succeeded ? "\u2713" : "\u2717";
          return `<span class="${cls}">${mark} @${entry.handle}</span>`;
        }).join(" \xB7 ");
      } else {
        progressWrap.classList.remove("show");
      }
      if (state.phase === "complete" && state.completeResult) {
        completeWrap.classList.add("show");
        progressWrap.classList.remove("show");
        const { succeeded, failed } = state.completeResult;
        completeText.innerHTML = failed > 0 ? `\u5B8C\u6210\uFF01\u6210\u529F <b>${succeeded}</b> \u4EBA\uFF0C\u5931\u8D25 <b>${failed}</b> \u4EBA` : `\u5B8C\u6210\uFF01\u6210\u529F\u53D6\u6D88\u5173\u6CE8 <b>${succeeded}</b> \u4EBA`;
      } else {
        completeWrap.classList.remove("show");
      }
    };
    paint(initialState);
    if (insertPoint !== null) {
      const { after } = insertPoint;
      const parent = after.parentElement;
      const before = after.nextElementSibling;
      if (parent !== null) {
        parent.insertBefore(host, before);
      } else {
        after.insertAdjacentElement("afterend", host);
      }
    } else if (fallbackAnchor !== null) {
      fallbackAnchor.prepend(host);
    } else {
      document.body.append(host);
    }
    return {
      root: host,
      update: paint,
      confirmUnfollow,
      remove: () => {
        dialogOverlay.classList.remove("show");
        dialogResolve?.(false);
        dialogResolve = null;
        host.remove();
      }
    };
  };

  // src/content/following-manager.ts
  var MIN_SYNC_INTERVAL_MS = 800;
  var SCROLL_SYNC_DEBOUNCE_MS = 200;
  var ACTIVATION_RETRY_MS = 500;
  var ACTIVATION_MAX_ATTEMPTS = 80;
  var TOOLBAR_GUARD_DEBOUNCE_MS = 150;
  var ROUTE_REACTIVATE_DEBOUNCE_MS = 80;
  var WATCHDOG_INTERVAL_MS = 2e3;
  var trackedPathname = "";
  var MAX_CELLS_PER_PASS = 40;
  var selectedHandles = /* @__PURE__ */ new Set();
  var filterMode = "one-way";
  var toolbar = null;
  var busy = false;
  var statusText = "\u52FE\u9009\u540E\u6279\u91CF\u53D6\u5173";
  var seenHandles = /* @__PURE__ */ new Set();
  var seenOneWayHandles = /* @__PURE__ */ new Set();
  var activationAttempts = 0;
  var activationRetryId = 0;
  var syncDebounceTimer = 0;
  var syncLoopTimer = 0;
  var lastSyncAt = 0;
  var lastToolbarSignature = "";
  var pageActive = false;
  var toolbarGuardObserver = null;
  var toolbarGuardTimer = 0;
  var checkboxGuardObserver = null;
  var scrollCheckboxResyncRaf = 0;
  var watchdogTimer = 0;
  var hasToolbarInDom = () => listFollowingToolbarHosts().length > 0;
  var dedupeToolbarHostsInDom = () => {
    const hosts = listFollowingToolbarHosts();
    if (hosts.length === 0) {
      if (toolbar !== null && !toolbar.root.isConnected) toolbar = null;
      return;
    }
    const owned = toolbar !== null && toolbar.root.isConnected && hosts.includes(toolbar.root) ? toolbar.root : null;
    for (const host of hosts) {
      if (host !== owned) host.remove();
    }
    if (owned === null) {
      removeAllFollowingToolbarHosts();
      toolbar = null;
      lastToolbarSignature = "";
    }
  };
  var stopWatchdog = () => {
    if (watchdogTimer === 0) return;
    window.clearInterval(watchdogTimer);
    watchdogTimer = 0;
  };
  var startWatchdog = () => {
    stopWatchdog();
    watchdogTimer = window.setInterval(() => tryActivateFollowingPage(), WATCHDOG_INTERVAL_MS);
  };
  var takeOverManagerSlot = () => {
    window.__xfmManagerSlot?.destroy();
    window.__xfmManagerSlot = {
      destroy: () => {
        stopActivationRetry();
        stopSyncLoop();
        stopToolbarGuard();
        stopCheckboxGuard();
        if (scrollCheckboxResyncRaf !== 0) {
          window.cancelAnimationFrame(scrollCheckboxResyncRaf);
          scrollCheckboxResyncRaf = 0;
        }
        stopWatchdog();
        destroyPageState();
      }
    };
  };
  var readCounts = () => {
    const cells = listLoadedUserCells(filterMode);
    for (const cell of cells) {
      const handle = extractUserCellHandle(cell);
      if (handle !== null) {
        seenHandles.add(handle);
        if (!userCellFollowsYou(cell)) seenOneWayHandles.add(handle);
      }
    }
    return { loadedCount: cells.length, selectedCount: selectedHandles.size };
  };
  var buildToolbarState = (counts) => ({
    filterMode,
    loadedCount: seenHandles.size,
    selectedCount: counts.selectedCount,
    busy,
    statusText,
    phase: "normal",
    oneWayCount: seenOneWayHandles.size
  });
  var selectAllSeenHandles = () => {
    for (const handle of seenHandles) selectedHandles.add(handle);
    syncViewportCheckboxes(true);
  };
  var toolbarSignature = (state) => `${state.filterMode}|${state.loadedCount}|${state.selectedCount}|${state.busy}|${state.statusText}|${state.phase}`;
  var updateToolbar = (force = false) => {
    const state = buildToolbarState(readCounts());
    const signature = toolbarSignature(state);
    if (!force && signature === lastToolbarSignature) return;
    lastToolbarSignature = signature;
    toolbar?.update(state);
  };
  var bindCheckboxListener = (input) => {
    if (input.dataset.xfmBound === "true") return;
    input.dataset.xfmBound = "true";
    input.addEventListener("change", () => {
      applyCheckboxChangeToSelection(input, selectedHandles);
      updateToolbar();
    });
  };
  var bindCheckboxOnCellIfPresent = (cell) => {
    const mount = resolveUserCellMount(cell);
    const handle = extractUserCellHandle(mount.userCell);
    const input = findOrReuseCheckboxInput(mount, handle);
    if (input !== null) bindCheckboxListener(input);
  };
  var syncCheckboxOnViewportCell = (cell, attachIfMissing) => {
    try {
      if (attachIfMissing && cellNeedsCheckboxAttach(cell)) {
        syncCheckboxOnCell(cell, selectedHandles, filterMode);
        bindCheckboxListener(ensureUserCellCheckbox(cell));
        return;
      }
      syncCheckboxOnCell(cell, selectedHandles, filterMode);
      bindCheckboxOnCellIfPresent(cell);
    } catch (error) {
      console.error("[xfm] \u52FE\u9009\u6846\u540C\u6B65\u5931\u8D25", error);
    }
  };
  var syncViewportCheckboxes = (attachMissing = true) => {
    if (!isFollowingListPage(location.pathname)) return 0;
    const loggedInKey = readLoggedInUserKey();
    if (!isOwnFollowingListPage(location.pathname, loggedInKey, document)) return 0;
    const targets = listViewportUserCells(filterMode);
    let processed = 0;
    for (const cell of targets) {
      syncCheckboxOnViewportCell(cell, attachMissing);
      const handle = extractUserCellHandle(cell);
      if (handle !== null) {
        seenHandles.add(handle);
        if (!userCellFollowsYou(cell)) seenOneWayHandles.add(handle);
      }
      processed += 1;
      if (processed >= MAX_CELLS_PER_PASS) break;
    }
    if (toolbar !== null) updateToolbar();
    return processed;
  };
  var runThrottledSync = (force = false) => {
    if (busy) return;
    if (!pageActive && !hasToolbarInDom()) return;
    const now = Date.now();
    if (!force && now - lastSyncAt < MIN_SYNC_INTERVAL_MS) return;
    lastSyncAt = now;
    syncViewportCheckboxes();
  };
  var scheduleScrollCheckboxStateResync = () => {
    if (busy || !pageActive) return;
    if (scrollCheckboxResyncRaf !== 0) return;
    scrollCheckboxResyncRaf = window.requestAnimationFrame(() => {
      scrollCheckboxResyncRaf = 0;
      if (!isFollowingListPage(location.pathname)) return;
      applySelectionToViewportCells(selectedHandles, filterMode);
    });
  };
  var scheduleSync = (force = false) => {
    scheduleScrollCheckboxStateResync();
    if (syncDebounceTimer !== 0) window.clearTimeout(syncDebounceTimer);
    syncDebounceTimer = window.setTimeout(() => {
      syncDebounceTimer = 0;
      runThrottledSync(force);
    }, force ? 0 : SCROLL_SYNC_DEBOUNCE_MS);
  };
  var startSyncLoop = () => {
    if (syncLoopTimer !== 0) return;
    syncLoopTimer = window.setInterval(() => {
      runThrottledSync(false);
      for (const cell of listLoadedUserCells(filterMode)) {
        syncCheckboxOnCell(cell, selectedHandles, filterMode);
      }
    }, MIN_SYNC_INTERVAL_MS + 400);
  };
  var stopSyncLoop = () => {
    if (syncDebounceTimer !== 0) {
      window.clearTimeout(syncDebounceTimer);
      syncDebounceTimer = 0;
    }
    if (syncLoopTimer !== 0) {
      window.clearInterval(syncLoopTimer);
      syncLoopTimer = 0;
    }
  };
  var stopToolbarGuard = () => {
    toolbarGuardObserver?.disconnect();
    toolbarGuardObserver = null;
    if (toolbarGuardTimer !== 0) {
      window.clearTimeout(toolbarGuardTimer);
      toolbarGuardTimer = 0;
    }
  };
  var stopCheckboxGuard = () => {
    checkboxGuardObserver?.disconnect();
    checkboxGuardObserver = null;
  };
  var startCheckboxGuard = () => {
    const column = findPrimaryColumn();
    if (column === null || checkboxGuardObserver !== null) return;
    checkboxGuardObserver = new MutationObserver(() => {
      if (busy) return;
      scheduleSync(false);
    });
    checkboxGuardObserver.observe(column, { childList: true, subtree: true });
  };
  var scheduleToolbarGuard = () => {
    if (!isFollowingListPage(location.pathname)) return;
    if (toolbarGuardTimer !== 0) window.clearTimeout(toolbarGuardTimer);
    toolbarGuardTimer = window.setTimeout(() => {
      toolbarGuardTimer = 0;
      if (!isFollowingListPage(location.pathname)) return;
      const loggedInKey = readLoggedInUserKey();
      if (!isOwnFollowingListPage(location.pathname, loggedInKey, document)) return;
      dedupeToolbarHostsInDom();
      if (!hasToolbarInDom()) ensureToolbar();
      else refreshToolbarStickyTop();
    }, TOOLBAR_GUARD_DEBOUNCE_MS);
  };
  var startToolbarGuard = () => {
    const column = findPrimaryColumn();
    if (column === null || toolbarGuardObserver !== null) return;
    toolbarGuardObserver = new MutationObserver(() => scheduleToolbarGuard());
    toolbarGuardObserver.observe(column, { childList: true, subtree: true });
  };
  var destroyPageState = () => {
    stopActivationRetry();
    stopSyncLoop();
    stopToolbarGuard();
    stopCheckboxGuard();
    pageActive = false;
    toolbar?.remove();
    toolbar = null;
    seenHandles.clear();
    seenOneWayHandles.clear();
    removeFollowingFilterStyles();
    removeCheckboxSpaceReservation();
    document.getElementById("xfm-checkbox-theme-style")?.remove();
    removeUserCellCheckboxes();
    selectedHandles.clear();
    busy = false;
    statusText = "\u52FE\u9009\u540E\u6279\u91CF\u53D6\u5173";
    lastToolbarSignature = "";
    lastSyncAt = 0;
  };
  var ensureToolbar = () => {
    dedupeToolbarHostsInDom();
    const insertPoint = findFollowingListInsertPoint();
    const fallbackAnchor = findFollowingToolbarFallbackAnchor();
    if (toolbar !== null && toolbar.root.isConnected) {
      if (insertPoint === null || isToolbarMountedAtListTop(toolbar.root, insertPoint)) {
        dedupeToolbarHostsInDom();
        updateToolbar(true);
        return true;
      }
      toolbar.remove();
      toolbar = null;
      lastToolbarSignature = "";
    }
    if (listFollowingToolbarHosts().length > 0) {
      removeAllFollowingToolbarHosts();
      toolbar = null;
      lastToolbarSignature = "";
    }
    if (insertPoint === null && fallbackAnchor === null) return false;
    const counts = readCounts();
    toolbar = mountFollowingToolbar(
      insertPoint,
      fallbackAnchor,
      {
        onFilterModeChange: (mode) => {
          if (busy) return;
          filterMode = mode;
          setFollowingFilterMode(mode);
          lastSyncAt = 0;
          runThrottledSync(true);
        },
        onSelectAll: () => {
          if (busy) return;
          selectAllSeenHandles();
          updateToolbar(true);
        },
        onClearSelection: () => {
          if (busy) return;
          selectedHandles.clear();
          setAllLoadedChecked(false, filterMode, selectedHandles);
          updateToolbar(true);
        },
        onUnfollowSelected: () => {
          void handleUnfollowSelected();
        }
      },
      buildToolbarState(counts)
    );
    lastToolbarSignature = toolbarSignature(buildToolbarState(counts));
    return hasToolbarInDom();
  };
  var activatePageUi = () => {
    if (!isFollowingListPage(location.pathname)) {
      destroyPageState();
      return false;
    }
    const loggedInKey = readLoggedInUserKey();
    if (!isOwnFollowingListPage(location.pathname, loggedInKey, document)) {
      destroyPageState();
      return false;
    }
    reserveCheckboxSpace();
    injectCheckboxTheme();
    setFollowingFilterMode(filterMode);
    const toolbarReady = ensureToolbar();
    pageActive = toolbarReady;
    if (pageActive) {
      startToolbarGuard();
      startCheckboxGuard();
      refreshToolbarStickyTop();
      runThrottledSync(true);
      startSyncLoop();
    }
    return pageActive;
  };
  var handleUnfollowSelected = async () => {
    if (busy) return;
    const remainingHandles = new Set(selectedHandles);
    if (remainingHandles.size === 0) {
      statusText = "\u8BF7\u5148\u52FE\u9009\u8981\u53D6\u6D88\u5173\u6CE8\u7684\u7528\u6237";
      updateToolbar(true);
      return;
    }
    const findLoadedCells = () => {
      const cells = [];
      for (const handle of remainingHandles) {
        const cell = findUserCellByHandle(handle);
        if (cell !== null) cells.push(cell);
      }
      return cells;
    };
    const initialCells = findLoadedCells();
    if (toolbar === null) return;
    const confirmed = await toolbar.confirmUnfollow(initialCells.length, remainingHandles.size);
    if (!confirmed) return;
    busy = true;
    const logBuffer = [];
    let totalSucceeded = 0;
    let totalFailed = 0;
    const totalSelected = remainingHandles.size;
    const pushProgress = () => {
      if (toolbar === null) return;
      toolbar.update({
        ...buildToolbarState({ loadedCount: listLoadedUserCells(filterMode).length, selectedCount: remainingHandles.size }),
        busy: true,
        phase: "progress",
        progress: { done: totalSucceeded + totalFailed, total: totalSelected, recentLog: logBuffer.slice(-3) }
      });
    };
    const SCROLL_STEP = 800;
    const SCROLL_WAIT_MS = 1200;
    const MAX_SCROLL_ATTEMPTS = 50;
    for (let attempt = 0; attempt < MAX_SCROLL_ATTEMPTS && remainingHandles.size > 0; attempt += 1) {
      const batch = findLoadedCells();
      if (batch.length === 0) {
        window.scrollBy(0, SCROLL_STEP);
        await new Promise((r) => window.setTimeout(r, SCROLL_WAIT_MS));
        continue;
      }
      pushProgress();
      for (let i = 0; i < batch.length; i += 1) {
        const cell = batch[i];
        const handle = extractUserCellHandle(cell);
        const ok = await unfollowUserCell(cell);
        if (ok) {
          totalSucceeded += 1;
          if (handle !== null) remainingHandles.delete(handle);
        } else {
          totalFailed += 1;
        }
        logBuffer.push({ handle: handle ?? `#${i + 1}`, succeeded: ok });
        pushProgress();
        if (i < batch.length - 1) {
          await new Promise((r) => window.setTimeout(r, 1e3));
        }
      }
      if (remainingHandles.size > 0) {
        window.scrollBy(0, SCROLL_STEP);
        await new Promise((r) => window.setTimeout(r, SCROLL_WAIT_MS));
      }
    }
    selectedHandles.clear();
    setAllLoadedChecked(false, filterMode, selectedHandles);
    busy = false;
    statusText = totalFailed > 0 ? `\u5B8C\u6210\uFF1A\u6210\u529F ${totalSucceeded}\uFF0C\u5931\u8D25 ${totalFailed}` : `\u5B8C\u6210\uFF1A\u6210\u529F\u53D6\u6D88\u5173\u6CE8 ${totalSucceeded} \u4EBA`;
    if (toolbar !== null) {
      toolbar.update({
        ...buildToolbarState({ loadedCount: listLoadedUserCells(filterMode).length, selectedCount: 0 }),
        busy: false,
        phase: "complete",
        completeResult: { succeeded: totalSucceeded, failed: totalFailed }
      });
    }
    lastSyncAt = 0;
    runThrottledSync(true);
    window.setTimeout(() => {
      statusText = "\u52FE\u9009\u540E\u6279\u91CF\u53D6\u5173";
      updateToolbar(true);
    }, 3e3);
  };
  var stopActivationRetry = () => {
    if (activationRetryId !== 0) {
      window.clearInterval(activationRetryId);
      activationRetryId = 0;
    }
    activationAttempts = 0;
  };
  var startActivationRetry = () => {
    stopActivationRetry();
    const tick = () => {
      activationAttempts += 1;
      const ready = activatePageUi();
      const done = ready && hasToolbarInDom() || activationAttempts >= ACTIVATION_MAX_ATTEMPTS;
      if (done) stopActivationRetry();
    };
    tick();
    activationRetryId = window.setInterval(tick, ACTIVATION_RETRY_MS);
  };
  var tryActivateFollowingPage = () => {
    if (!isFollowingListPage(location.pathname)) {
      destroyPageState();
      return;
    }
    if (!hasToolbarInDom() || !pageActive) {
      startActivationRetry();
      return;
    }
    lastSyncAt = 0;
    syncViewportCheckboxes();
  };
  var routeReactivateTimer = 0;
  var notifyPathnameChange = () => {
    const pathname = location.pathname;
    if (pathname === trackedPathname) return;
    trackedPathname = pathname;
    destroyPageState();
    tryActivateFollowingPage();
  };
  var scheduleRouteReactivate = () => {
    if (routeReactivateTimer !== 0) window.clearTimeout(routeReactivateTimer);
    routeReactivateTimer = window.setTimeout(() => {
      routeReactivateTimer = 0;
      notifyPathnameChange();
    }, ROUTE_REACTIVATE_DEBOUNCE_MS);
  };
  var patchHistoryNavigation = () => {
    trackedPathname = location.pathname;
    for (const method of ["pushState", "replaceState"]) {
      const original = history[method];
      history[method] = function patchedHistoryMethod(...args) {
        const result = original.apply(this, args);
        scheduleRouteReactivate();
        return result;
      };
    }
    window.addEventListener("popstate", notifyPathnameChange);
  };
  var refreshToolbarStickyTop = () => {
    const host = document.querySelector(`[${TOOLBAR_HOST_ATTR}]`) ?? toolbar?.root ?? null;
    if (host === null) return;
    applyToolbarStickyLayout(host);
  };
  var installPassiveSyncTriggers = () => {
    window.addEventListener(
      "scroll",
      () => {
        refreshToolbarStickyTop();
        scheduleSync(false);
      },
      { passive: true, capture: true }
    );
    window.addEventListener(
      "resize",
      () => {
        refreshToolbarStickyTop();
        scheduleSync(false);
      },
      { passive: true }
    );
  };
  var buildStatus = () => ({
    path: location.pathname,
    marker: document.documentElement?.getAttribute("data-xfm-extension"),
    coreInit: window.__xfmCoreInit === true,
    pageActive,
    toolbar: hasToolbarInDom(),
    checkboxes: document.querySelectorAll("[data-xfm-follow-select-input]").length,
    insertPoint: findFollowingListInsertPoint() !== null,
    primaryColumn: findPrimaryColumn() !== null,
    ownPage: isOwnFollowingListPage(location.pathname, readLoggedInUserKey(), document)
  });
  var initCoreOnce = () => {
    if (window.__xfmCoreInit) return;
    window.__xfmCoreInit = true;
    document.documentElement?.setAttribute("data-xfm-extension", "loaded");
    patchHistoryNavigation();
    installPassiveSyncTriggers();
    window.__xfmStatus = buildStatus;
  };
  var bootstrap = () => {
    try {
      initCoreOnce();
      takeOverManagerSlot();
      startWatchdog();
      tryActivateFollowingPage();
    } catch (error) {
      console.error("[xfm] X \u6E05\u9053\u592B\u542F\u52A8\u5931\u8D25", error);
    }
  };
  var runBootstrap = () => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
      return;
    }
    bootstrap();
  };
  runBootstrap();
})();
